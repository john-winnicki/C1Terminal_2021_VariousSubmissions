package com.c1games.terminal.algo;

import com.google.gson.annotations.SerializedName;

public enum PlayerId {
    @SerializedName("0") Error,
    @SerializedName("1") Player1,
    @SerializedName("2") Player2,
}
